# handlebars-guide
A simple guide covering the basics of the handlebars templating engine
https://medium.com/@waelyasmina/a-guide-into-using-handlebars-with-your-express-js-application-22b944443b65
