# html-pdf-node-demo

Answer to the Stackoverflow question: https://stackoverflow.com/questions/66344473/css-and-image-not-showing-in-rendered-pdf-using-html-pdf-node
